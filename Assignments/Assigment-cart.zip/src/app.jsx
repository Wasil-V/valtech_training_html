import Users from "./user.component"

let App =()=>{
    return <div>
        <h1>Avengers Store</h1>
        <Users/>
    </div>
}
export default App