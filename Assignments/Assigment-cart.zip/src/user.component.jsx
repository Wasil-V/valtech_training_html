import { useEffect } from "react"
import axios from "axios";
import { useState } from "react";
 
var total=0
let Users = ()=>{
    let [hero, setHeroes] = useState([]);
    let [qty,getQty] = useState({qty:0});
    let [nproduct,setCart]=useState({_id:'',hero:'',name:'',price:'',instock:true})
 
    let refresh = ()=>{
        axios.get("http://localhost:7080/data").then(res => {
            setHeroes(res.data);
        })
    }
    let clickHandler=(evt)=>{
        getQty({...qty, qty : Number(evt.target.value)})
    }
    let addCart=(pid)=>{
        axios.get("http://localhost:7080/edit/"+pid).then(res => {
            setCart(res.data);
            total+=qty.qty*res.data.price;
            
        })
    }
 
    useEffect(function(){
       refresh();
    },[]);
    return <div className="carthome" style={{margin : "50px" }}>
        <div className="cart">
            {hero.map((hero,idx)=>{
                return <div className="box">
                    <div className="products">
                    Hero : {hero.hero}
                    <br />
                    Name : {hero.name}
                    <br />
                    Price : {hero.price}
                    <br />
                    <label htmlFor="" className="qty">Quantity : 
                    <input min="0" style={{width:60,marginLeft:10,backgroundColor:"black",color:"yellow"}} onInput={(evt)=>clickHandler(evt)} type="number" />
                    </label>
                    <button className="btn btn-warning" onClick={()=>addCart(hero._id)} style={{marginLeft:70}}>Add to cart</button>
                    </div>

                </div>
            })}
            </div>
            <div className="finalcart">
                <center><h2 style={{color:"yellow"}}>My Cart</h2></center>
                <hr />
                    <h5 style={{marginLeft:20}}>Hero : {nproduct.hero}</h5>
                    <h5 style={{marginLeft:20}}>Price : {nproduct.price}</h5>
                    <h5 style={{marginLeft:20}}>Quantity : {qty.qty}</h5>
                    <hr />
               <h3 style={{marginLeft:20}}>Total : {total}</h3>
               <hr />
            </div>
        
    </div>

    
                
                    {/* {
                        hero.map((hero, idx) =>{
                            return <tr key={hero._id}>
                                        <th scope="row">{ idx + 1 }</th>
                                        <td>{ hero.hero }</td>
                                        <td>{ hero.name }</td>
                                        <td>{ hero.price }</td>
                                        <td>{ hero.instock }</td>
                                        <td><button className="btn btn-warning">Edit</button></td>
                                        <td><button className="btn btn-danger">Delete</button></td>
                                    </tr>
                        })
                    } */}
              

                }
export default Users 
 
 