
import {BrowserRouter, NavLink, Route, Routes} from "react-router-dom"
import data from "./data.json"
import DetailsComp from "./details.component"

function App(){
    return <div>
        <h1>Heroes List</h1>
        <BrowserRouter>
        {

                    data.heroes.map((val,idx)=>{
                        return <div className="links">
                             <ul>
                            <li>
                                <NavLink to={"/details/"+val.id}>{val.name}</NavLink>
                            </li>
                        </ul>
                        </div>

                    })
        }
        <br />
        <Routes>
            <Route path="/details/:hid" element={<DetailsComp/>}></Route>
        </Routes>
        </BrowserRouter>
    </div>
}

export default App