import { useParams } from "react-router-dom"
import data from "./data.json"
function DetailsComp(){
    let params = useParams()
    let hid = params.hid;
    // console.log(heroData);
    return <div className="details">
        <h1>Details</h1>
        {data.heroes.map((val)=>{
            if(hid===val.id){
                return <div>
                    <h2>Name : {val.name}</h2>
                    <br />
                    <b>PowerStats:</b>
                    <ul>
                        <li>Intelligence : {val.powerstats.intelligence}</li>
                        <li>Strength : {val.powerstats.strength}</li>
                        <li>Speed : {val.powerstats.speed}</li>
                        <li>Power : {val.powerstats.power}</li>
                    </ul>
                    <b>Biography:</b>
                    <ul>
                        <li>Full Name : {val.biography["full-name"]}</li>
                        <li>Place of Birth: {val.biography["place-of-birth"]}</li>
                        <li>Publisher : {val.biography.publisher}</li>
                    </ul>
                    <b>Appearance:</b>
                    <ul>
                        <li>Gender : {val.appearance.gender}</li>
                        <li>Race : {val.appearance.race}</li>
                        <li>Height : {val.appearance.height}</li>
                        <li>Weight : {val.appearance.weight}</li>
                    </ul>
                </div>
                    
                
            }
        })}
    
    </div>
}

export default DetailsComp