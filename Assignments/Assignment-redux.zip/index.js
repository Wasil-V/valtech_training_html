const redux = require("redux")
const process = require("process")
const fs = require("fs")

const createStore = redux.legacy_createStore
let herodata = `First Name: ${process.argv[2]}\nLast Name : ${process.argv[3]}\nPower : ${process.argv[4]}\n `
fs.appendFile("temp.txt",herodata,"utf-8",function(err,data){
    if(err){console.log("Error ",err)}
    else{console.log("content is added")}
})
const ADDHERO = "ADDHERO";


let addhero =function(){
    return{
        type : ADDHERO,

    }
}


let InitialState ={
    hero : ""
}

let data = fs.readFileSync("temp.txt","utf-8");

let reducer =(state = InitialState,action)=>{
    switch(action.type){
        case ADDHERO : return { 
                    hero : data

            } 
         
        default : return state
    }
}

let store = createStore(reducer)

console.log("innitial state ", store.getState())

let unsubscribe = store.subscribe(()=>console.log(store.getState()))

store.dispatch(addhero());
store.dispatch(addhero());







