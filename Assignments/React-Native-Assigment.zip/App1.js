import { StyleSheet, Text, View, Platform } from "react-native";

export default function App(){
  return (
    <View style={[styles.container, {
      flexDirection: "column"
    }]}>
      <View style={{ flex: 2, backgroundColor: "#8e9aaf" }} />
      <View style={{ flex: 5, backgroundColor: "#cbc0d3" }} />
      <View style={{ flex: 3, backgroundColor: "#efd3d7" }} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop : Platform.OS === "android" && 25 || Platform.OS === "ios" && 33
  },
});




