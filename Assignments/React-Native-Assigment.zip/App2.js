import { useState } from "react";
import { StyleSheet, Text, View, Platform, Pressable, Button } from "react-native";

export default function App(){
  let [colors, setColor] = useState("");
  return (
    <View style={[styles.container, {
      float : "left",
      flexDirection : "row",
      backgroundColor : colors

  
    }]}>
      {/* <View style={{ width : 400, height : 700, backgroundColor: colors }}></View> */}
      <Pressable onPress={()=>setColor("#8e9aaf")}>
      <View style={{ width : 98, height :98, backgroundColor: "#8e9aaf" }} />
      </Pressable>
      <Pressable onPress={()=>setColor("#cbc0d3")}>
      <View style={{ width : 98, height :98, backgroundColor: "#cbc0d3" }} />
      </Pressable>
      <Pressable onPress={()=>setColor("#efd3d7")}>
      <View style={{ width : 98, height :98, backgroundColor: "#efd3d7" }} />
      </Pressable>
      <Pressable onPress={()=>setColor("#e7dbeb")}>
      <View style={{ width : 98, height :98, backgroundColor: "#e7dbeb" }} />
      </Pressable>
      
    </View>
    
  );
};

const styles = StyleSheet.create({
  container: {
    flex : 1,
    display : "flex",
    paddingTop : Platform.OS === "android" && 45 || Platform.OS === "ios" && 33,
    alignItems : "flex-end"
  }
});




