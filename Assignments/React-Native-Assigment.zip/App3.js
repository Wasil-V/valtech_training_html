import { useState } from "react";
import { StyleSheet, Text, View, Platform, Pressable, Button,Image } from "react-native";
import antman from "./assets/antman.jpg"
import hulk from "./assets/hulk.jpg"
import batman from "./assets/batman.jpg"

export default function App(){
  let [hero, setHero] = useState("");
  let [pic, setPic] = useState("");
  let changehero =(name,pics)=>{
    setHero(name);
    setPic(pics)

  }
  return (
    <View style={styles.container}>
      <Text style={{fontSize : 30, color : "white"}}>      Title : {hero} </Text>
      <View style={{width : 300, height : 300}}><Image source={pic}></Image></View>
      <Text></Text>
      <Button title="Antman" onPress={()=>changehero("Antman",antman)} ></Button>
      <Text></Text>
      <Button title="Hulk" onPress={()=>changehero("Hulk",hulk)} ></Button>
      <Text></Text>
      <Button title="Aquaman" onPress={()=>changehero("Aquaman",batman)}></Button>
      <Text></Text>
    </View>
    
  );
};

const styles = StyleSheet.create({
  container: {
    flex : 1,
    display : "flex",
    paddingTop : Platform.OS === "android" && 45 || Platform.OS === "ios" && 33,
    padding : 50,
    backgroundColor : "black",
    borderWidth : 2,
    borderColor : "yellow"
  }
 
});




