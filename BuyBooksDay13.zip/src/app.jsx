import { Component } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Details from "./components/details.component";
import Main from "./components/main.component";

class App extends Component {
  render() {
    return (
      <div>
        <BrowserRouter>
          <Routes>
            {/*  */}
            <Route path="/" element={<Main />} />
            <Route path="/details/:id" element={<Details />} />
          </Routes>
        </BrowserRouter>
      </div>
    );
  }
}

export default App;
