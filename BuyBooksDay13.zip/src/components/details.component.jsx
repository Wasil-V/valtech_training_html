import background from "../assets/background.jpg";
import book from "../data/details.json";
import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import Header from "./header.component";
import moment from "moment"

let Details = () => {

  let params = useParams();
  let data = book.data;
  let hid = params.id;
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
    }, 500);
  }, []);

  return (
    <div id="detailCont">
      <Header />
      <br />
      {loading ? <div class="d-flex justify-content-center">
        <div class="spinner-border text-success m-5" style={{ width: 50, height: 50 }} role="status">
          <span class="sr-only"></span>
        </div>
      </div> : <div id="maincard" className="card mb-3">
        <div className="row g-0">
          <div className="col-md-6 ">
            <div className="card-body">
              {data.map((val, idx) => {
                if (val._id === hid) {
                  return (
                    <div id="cardback" key={idx}>
                      <h3 className="card-title">₹{val.title} /-</h3>
                      <div className="cardbtn">
                        College : {val.college}
                      </div>
                      <div className="cardbtn">
                        Year : {val.year}
                      </div>
                      <div className="cardbtn">
                        Branch : {val.branch}
                      </div>
                      <span>Created By : {val.name}</span>
                      <div>
                        <span>{moment(val.createdAt).fromNow()}</span>
                      </div>
                      <hr />
                      <br />
                      <hr />
                    </div>
                  )
                }
              })}
            </div>
          </div>
          <div className="col-md-6">
            <img
              id="detimg"
              src={background}
              className="img-fluid rounded-start"
              alt="..."
            />
          </div>
        </div>
      </div>}
    </div>
  );
};

export default Details;
