import { useDispatch } from "react-redux";
import { searchbook } from "../redux/";
import React from "react";
import { useRef, useState } from "react";

let Search = () => {

  let [validateStateCollege, changeValidateStateCollege] = useState();
  let [validateStateBook, changeValidateStateBook] = useState();


  var book = "";
  var college = "";

  let inputFeildBook = useRef();
  let inputFeildCollege = useRef();
  let ValidateCollege = useRef();
  let ValidateBook = useRef();
  let dispatch = useDispatch();

  let setBook = (e) => {
    book = e.target.value;
    book = book.toLowerCase().trim();
    if (book != "") {
      changeValidateStateBook("");
      changeValidateStateCollege("");
    }
  };

  let setCollege = (e) => {
    college = e.target.value;
    college = college.toLowerCase().trim();
    if (college != "") {
      changeValidateStateCollege("");
      changeValidateStateBook("");
    }
  };

  let clearSearch = (e) => {
    e.preventDefault();

    inputFeildBook.current.value = "";
    inputFeildCollege.current.value = "";

    if (
      inputFeildBook.current.value === "" &&
      inputFeildCollege.current.value === ""
    ) {
      changeValidateStateCollege("Please Enter College");
      changeValidateStateBook("Please Enter Book");
    }

    if (
      inputFeildBook.current.value !== "" ||
      inputFeildCollege.current.value !== ""
    ) {
      ValidateCollege.current = "";
      ValidateBook.current = "";
    }
  };

  return (
    <div id="searchbox">
      <form action="#">
        <div className="mb-1">
          <label htmlFor="college" className="form-label"></label>
          <input
            placeholder="Search By College"
            onInput={(e) => {
              setCollege(e);
            }}
            autoComplete={"off"}
            type="text"
            className="form-control"
            id="college"
            name="college"
            ref={inputFeildCollege}
            required
          />
          <span style={{ color: "red", margin: "0px" }} className="valspan">
            {validateStateCollege}
          </span>
        </div>
        <div className="mb-2">
          <label htmlFor="book" className="form-label"></label>
          <input
            placeholder="Search By Book"
            onInput={(e) => {
              setBook(e);
            }}
            type="text"
            autoComplete={"off"}
            className="form-control"
            id="book"
            name="book"
            ref={inputFeildBook}
            required
          />
          <span style={{ color: "red", margin: "0px" }} className="valspan">
            {validateStateBook}
          </span>
        </div>
        <br />
        <button
          className="searchBtn"
          onClick={(e) => {
            dispatch(searchbook(book, college));
            clearSearch(e);
          }}
        >
          Search
        </button>
      </form>
    </div>
  );
};

export default Search;
