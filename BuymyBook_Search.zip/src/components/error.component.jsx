let ErrorHandler = () => {
    return (
      <div style={{ width: 1320 }}>
        <br />
        <h1>404 Error Not Found</h1>
      </div>
    );
  };
  
  export default ErrorHandler;
  