import { useSelector, useDispatch } from "react-redux";
// import { NavLink } from "react-router-dom";
import { searchbook } from "../redux/";
import React from "react";
import { useRef,useState} from "react";
let Search = () => {
  let [validateState,changeValidateState]=useState()
  let [validateState1,changeValidateState1]=useState()
  var book = "";
  var college = "";
  let books = useSelector((state) => state.search.books);
  let colleges = useSelector((state) => state.search.colleges);
  let inputFeildBook = useRef()
  let inputFeildCollege = useRef()
  let ValidateCollege = useRef()
  let ValidateBook = useRef()
  let dispatch = useDispatch();

  let setBook = (e) => {
    book = e.target.value;
    book = book.toLowerCase().trim()
    if(book!=""){
    
      changeValidateState1("")
      changeValidateState("")

    }
  };

  let setCollege = (e) => {
    college = e.target.value;
    college = college.toLowerCase().trim()  
    if(college!=""){
      changeValidateState("")
      changeValidateState1("")

    }
  };


  let clearSearch = (e) => {
    // console.log(inputFeildCollege.current.value)
    e.preventDefault();
   
    inputFeildBook.current.value=''
    inputFeildCollege.current.value=''

    if(inputFeildBook.current.value==='' && inputFeildCollege.current.value===''){
      // ValidateCollege.current="Please Enter College";
      // ValidateBook.current="Please Enter Book" 
      changeValidateState("Please Enter College")
      changeValidateState1("Please Enter Book" )
    }
  
    if(inputFeildBook.current.value!=='' || inputFeildCollege.current.value!==''){
      ValidateCollege.current="";
      ValidateBook.current=""
    }       
  }

  return (
    <div id="searchbox">
      <form action="#" > 
        <div className="mb-1">  
          <label htmlFor="college" className="form-label"></label>
          <input
            placeholder="Search By College"
            onInput={(e) => {setCollege(e) 
            
          }}
          autoComplete={'off'}
            // onClick={()=>validateOnChange() }
            type="text"
            className="form-control"
            id="college"
            name="college"
            ref={inputFeildCollege}
          />
          <span style={{ color: "red", margin: "0px"}} className="valspan">
            {validateState}
          </span>
        </div>
        <div className="mb-2">
          <label htmlFor="book" className="form-label"></label>
          <input 
            placeholder="Search By Book"
            onInput={(e) => {setBook(e)
                }}  
              // onClick={()=>validateOnChange() }
            type="text"
            autoComplete={'off'}
            className="form-control"
            id="book" 
            name="book" 
            ref={inputFeildBook}

          />
          <span style={{ color: "red", margin: "0px"}} className="valspan">{validateState1}</span>
          
        </div> 
        {/* <NavLink to={"/search/"+book}> */}
        <br />
        <button
         
         className="btn btn-primary"
         onClick={(e) => {dispatch(searchbook(book,college))
          clearSearch(e)}}
        //  onMouseDownCapture={()=>clearSearch()}
          style={{width:"220px"}}  
     
           
        >
          Search
        </button>
        {/* </NavLink> */}
      </form>
    </div>
  );
};

export default Search;
