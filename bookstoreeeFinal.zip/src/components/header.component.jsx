import '../styles/style.css';
import bookicon from "../assets/Book.png"
import { Link } from 'react-router-dom';

let Header = ()=>{
        return <div id="container">
            <a href="/" className="HeaderLink">
            <div id="bookhead">
                <h2>BuyBooks <img src={bookicon} alt="Logo" height={40} width={40}/></h2>
            </div>
                </a>
        </div>
    
}

export default Header;
