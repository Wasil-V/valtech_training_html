import Content from "./content.component";
import Header from "./header.component";

let Main = ()=>{
        return <div id="mainCont">
            <Header/>
            <Content/>
        </div>
    
}

export default Main