import background from "../assets/background.jpg";
import { useSelector } from "react-redux";
import like from "../assets/like.png";
import book from "../data/details.json";
import moment from "moment";
import { NavLink } from "react-router-dom";

let List = () => {
  let books = useSelector((state) => state.search.books);
  let colleges = useSelector((state) => state.search.colleges);
  var bookSearch = [];
  var collegeSearch = [];
  var found = true;
  var show = true;
  // let dispatch = useDispatch();
  Object.keys(books).forEach(function (item) {
    bookSearch.push(books[item]);
  });
  Object.keys(colleges).forEach(function (item) {
    collegeSearch.push(colleges[item]);
  })
  // console.log(collegeSearch[0].collegeName)

  let data = book.data;
  data.map((val) => {
     if ((bookSearch[0].bookName !== val.name && bookSearch[0].bookName !== "") || (collegeSearch[0].collegeName !== val.college && collegeSearch[0].collegeName !== "")) {
    //if ((bookSearch[0].bookName !== val.name && bookSearch[0].bookName !== "") ) {
      return [(show = false), (found = false)];
    }
  });
  data.map((val) => {
     if ((bookSearch[0].bookName == val.name) || (collegeSearch[0].collegeName == val.college)) {
    //if ((bookSearch[0].bookName == val.name)) {
      return [(show = false), (found = true)];
    }
  });
  data.map((val) => {
     if ((bookSearch[0].bookName == "") && (collegeSearch[0].collegeName == "")) {
    //if ((bookSearch[0].bookName == "")) {
      return [(show = true), (found = false)];
    }
  });
  // {
  //   console.log(show, "book", String(bookSearch[0].bookName), found);
  // }
  return (
    <div id="ahwp">
      <div className="row row-cols-1 row-cols-xl-4 row-cols-md-1 row-cols-lg-3   row-cols-sm-1 g-4">
        {/* {bookSearch[0].bookName} */}
        {show &&
          data.map((val, idx) => {
            return (
              <div className="col">
                <div className="card">
                  <NavLink to={"/details/" + val._id} className="cardlink">
                    <div id="cardNd">
                      <img 
                        src={background}
                        className="card-img-top"
                        alt="book"
                        id="listimg"
                      />
                      <div id="cardName">{val.name}</div>
                      <div id="cardDate">
                        <span>{moment(val.createdAt).fromNow()}</span>
                      </div>
                    </div>
                    <div id="cardback">
                      <button type="button" class="btn btn-light cardbtn">
                        College : {val.college}
                      </button>
                      <button type="button" class="btn btn-light cardbtn">
                        Year : {val.year}
                      </button>
                      <button type="button" class="btn btn-light cardbtn">
                        Branch : {val.branch}
                      </button>
                    </div>

                    <div id="price">
                      <h5>Rs. {val.title}/-</h5>
                    </div>
                    <div id="branch">
                      {val.tags.map((x, idx) => {
                        return (
                          <span id="bran">
                            {x} <br />
                          </span>
                        );
                      })}
                    </div>
                  </NavLink>
                  <div className="likes">
                    <span id="likenum">
                      {" "}
                      <img src={like} alt="like" width={25} height={25} />
                      {val.likes.length === 0 && `Like`}
                      {val.likes.length === 1 && val.likes.length + ` Like`}
                      {val.likes.length > 1 && val.likes.length + ` Likes`}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        {!show &&
          found &&
          data.map((val, idx) => {
            if (bookSearch[0].bookName == val.name || collegeSearch[0].collegeName == val.college) {
            // if (bookSearch[0].bookName == val.name) {
              return (
                <div className="col">
                  <div className="card">
                    <NavLink to={"/details/" + val._id} className="cardlink">
                      <div id="cardNd">
                        <img
                          src={background}
                          className="card-img-top"
                          alt="book"
                          id="listimg"
                        />
                        <div id="cardName">{val.name}</div>
                        <div id="cardDate">
                          <span>{moment(val.createdAt).fromNow()}</span>
                        </div>
                      </div>
                      <div id="cardback">
                        <button type="button" class="btn btn-light cardbtn">
                          College : {val.college}
                        </button>
                        <button type="button" class="btn btn-light cardbtn">
                          Year : {val.year}
                        </button>
                        <button type="button" class="btn btn-light cardbtn">
                          Branch : {val.branch}
                        </button>
                      </div>

                      <div id="price">
                        <h5>Rs. {val.title}/-</h5>
                      </div>
                      <div id="branch">
                        {val.tags.map((x, idx) => {
                          return (
                            <span id="bran">
                              {x} <br />
                            </span>
                          );
                        })}
                      </div>
                    </NavLink>
                    <div className="likes">
                      <span id="likenum">
                        {" "}
                        <img src={like} alt="like" width={25} height={25} />
                        {val.likes.length === 0 && `Like`}
                        {val.likes.length === 1 && val.likes.length + ` Like`}
                        {val.likes.length > 1 && val.likes.length + ` Likes`}
                      </span>
                    </div>
                  </div>
                </div>
              );
            }
          })}
        {!show && !found && <div id="notfound">Not Found</div>}
      </div>
    </div>
  );
};

export default List;
