let NotFound=()=>{
    return(
        <h1> found</h1>

    )
}
export default NotFound