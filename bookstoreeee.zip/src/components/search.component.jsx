import { useSelector, useDispatch } from "react-redux";
// import { NavLink } from "react-router-dom";
import { searchbook } from "../redux/";
import React from "react";
import { useRef } from "react";
let Search = () => {
  // let[formstate,changeState]=useState('')
  var book = "";
  var college = "";
  let books = useSelector((state) => state.search.books);
  let colleges = useSelector((state) => state.search.colleges);
  let inputFeildBook = useRef()
  let inputFeildCollege = useRef()
  let ValidateCollege = useRef()
  let ValidateBook = useRef()
  // let searchByCollege = useSelector(state => state.search.searchByCollege);
  var bookSearch = [];
  var collegeSearch = [];
  Object.keys(books).forEach(function (item) {
    bookSearch.push(books[item]);
  });
  Object.keys(colleges).forEach(function (item) {
    collegeSearch.push(colleges[item]);
  });
  let dispatch = useDispatch();
  let setBook = (e) => {
    book = e.target.value;
    ValidateBook.current="";
    
    // changeState(e.target.value)
  };
  let setCollege = (e) => {
    college = e.target.value;
    ValidateCollege.current="";
    
    
  };
  // let clearValidate = ()=>{
  //    return ValidateBook.current=""
  // }

  let clearSearch = (e) => {
    // console.log(inputFeildCollege.current.value)
    e.preventDefault();
    // inputFeildBook.current.value=''
    // inputFeildCollege.current.value=''
    if(inputFeildBook.current.value==='' && inputFeildCollege.current.value===''){
      ValidateCollege.current="Please Enter College";
      ValidateBook.current="Please Enter Book"
    }
    // if(books[0].bookName==''){
      
    //   ValidateBook.current="Please Enter Book"
    // }
    // if(colleges[0].collegeName==''){
    //   ValidateCollege.current="Please Enter College";
    // }
    if(inputFeildBook.current.value!=='' || inputFeildCollege.current.value!==''){
      ValidateCollege.current="";
      ValidateBook.current=""
    }       
  }

  return (
    <div id="searchbox">
      <form action="#"> 
        <div class="mb-1">  
          <label for="college" class="form-label"></label>
          <input
            placeholder="Search By College"
            onChange={(e) => setCollege(e)}
            type="text"
            class="form-control"
            id="college"
            name="college"
            ref={inputFeildCollege}
          />
          <span style={{ color: "red", margin: "0px" }} >
            {ValidateCollege.current}
          </span>
        </div>
        <div class="mb-2">
          <label for="book" class="form-label"></label>
          <input 
            placeholder="Search By Book"
            onChange={(e) => {setBook(e)
          // clearValidate()
       }}
            type="text"
            class="form-control"
            id="book"
            name="book"
            ref={inputFeildBook}
          />
          <span style={{ color: "red", margin: "0px" }}>{ValidateBook.current}</span>
        </div>
        {/* <NavLink to={"/search/"+book}> */}
        <button
          type="submit"
          onClick={(e) => {dispatch(searchbook(book,college))
          clearSearch(e)}}
          class="btn btn-primary"
        >
          Search
        </button>
        {/* </NavLink> */}
      </form>
    </div>
  );
};

export default Search;
