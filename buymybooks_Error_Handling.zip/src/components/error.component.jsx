import { Component } from "react";

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = {error: ""};
  }

  componentDidCatch(error) {
    this.setState({error: `${error}`});
  }

  render() {
    const {error} = this.state;
    if (error) {
      return (
        <div style={{width:1320}}>
          <br />
          <h1>Error 404</h1>
          </div>
      );
    } else {
      return <>{this.props.children}</>;
    }
  }
}

export default ErrorBoundary;