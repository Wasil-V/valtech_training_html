const EventEmitter= require("events").EventEmitter;
var count=0;
let MyEvent = new EventEmitter();
MyEvent.addListener("valtech",function(){
    console.log("event happened");
})
var ci =setInterval(function(){
    if(count<5){
    MyEvent.emit("valtech");
    count++;
    }
    else{
        clearInterval(ci);
    }

},1000)