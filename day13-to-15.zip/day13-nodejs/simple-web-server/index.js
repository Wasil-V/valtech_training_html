const http = require("http");

let server =http.createServer(function(req,res){
    res.writeHead(200,{"Content-Type":"text/plain"});
    res.write("Welcome Home");
    res.end();
});

server.listen(1010,"localhost",function(err){
    if(err){
        console.log("Error",err);
    }
    else{
        console.log("Server is now live on localhost:1010");
    }
})
