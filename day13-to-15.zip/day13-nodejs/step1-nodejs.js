var message1="Welcome Home";
var message2="Welcome Back";
function addr(num1,num2){
    return num1+num2
};

// console.log(message);
// console.log(__dirname);
console.log(__filename);
module.exports.msg={message1,message2,addr};