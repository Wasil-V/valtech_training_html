var obj= require("./step1-nodejs");
console.log(obj.msg.addr(5,4))