var os=require("os");
// console.log(os.arch());
// console.log(os.cpus());
// console.log(os.cpus().length);
console.log(os.totalmem()/(1024*1024*1024));
console.log(os.hostname());