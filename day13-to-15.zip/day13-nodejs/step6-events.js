const EventEmitter= require("events").EventEmitter;
let MyEvent = new EventEmitter();
MyEvent.addListener("valtech",function(){
    console.log("even happened");
})
setTimeout(function(){
    MyEvent.emit("valtech");
},2000)