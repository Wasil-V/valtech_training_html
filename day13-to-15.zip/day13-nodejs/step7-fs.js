const fs =require("fs");
// fs.writeFileSync("temp.txt","Welcome Back","utf-8");
// fs.writeFile("temp.txt","Welcome Back","utf-8",function(error,data){
//     if(error){
//         console.log("Error ",error)
//     }
//     else{
//         console.log("File Created");
//     }
// });

// console.log(fs.readFileSync("temp.txt","utf-8"));
// fs.readFile("temp.txt","utf-8",function(error,data){
//     if(error){
//                 console.log("Error ",error)
//             }
//             else{
//                 console.log(data);
//             }

// });
fs.watchFile("temp.txt",function(){
    console.log("file updated");
})
setInterval(function(){
    fs.appendFile("temp.txt","\nHello","utf-8",function(err,data){
        if(err){console.log("Error ",err)}
        else{console.log("content is added")}
    })
},2000)