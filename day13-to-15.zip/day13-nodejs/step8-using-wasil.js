var message= require("wasil_").msg;
console.log(message.message);