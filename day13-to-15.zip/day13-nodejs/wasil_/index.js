var message ='Welcome';
module.exports.msg={message};