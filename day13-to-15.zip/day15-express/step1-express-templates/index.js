const express = require("express");

let app =express();
var port = process.env.PORT || 6000;
console.log(port);

app.get("/",(req,res)=>{
    //res.sendFile(__dirname+"/public/index.html");
    // res.render("index.ejs",{
    //     compname : "Valtech",
    //     message : "Welcome Back"
    // })
    // app.set("views","tempalates")
    // app.set("view engine","ejs")
    res.render("index.pug",{
        compname : "Valtech",
        message : "Welcome Back"
    })
})
app.get("/about",(req,res)=>{
    //res.sendFile(__dirname+"/public/about.html");
    res.render("about.pug",{
        compname : "Valtech",
        message : "Welcome Back"
    })
})
app.get("/contact",(req,res)=>{
    //res.sendFile(__dirname+"/public/contact.html");
    res.render("contact.pug",{
        compname : "Valtech",
        message : "Welcome Back"
    })
})

app.listen(port,"localhost",function(error){
    if(error){
        console.log("Error ",error)
    }else{
        console.log(`The server is now live on localhost : ${port}`)
    }
})