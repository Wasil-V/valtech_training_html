const express = require("express");
 let app = express();

 let herolist=[];
 app.use(express.urlencoded({extended:true}));

 app.get("/",(req,res)=>{
    res.render("home.ejs",{
        compname : "valtech",
        herolist
    })
 })

 app.post("/",(req,res)=>{
    herolist.push(req.body.nhero);
    res.redirect("/");
    res.end();
 })

 app.listen(5050,"localhost",(err)=>{
    if(err){
        console.log("Error ",err)
    }else{
        console.log("Server is now live on localhost:5050");
    }
 })