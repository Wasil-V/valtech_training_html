const express = require("express");
const mongoose= require("mongoose");
const cors = require("cors");
//mongodb+srv://admin:6DRyFCu4xG4PABVo@cluster0.x4x3eny.mongodb.net/?retryWrites=true&w=majority
let url = "mongodb+srv://admin:6DRyFCu4xG4PABVo@cluster0.x4x3eny.mongodb.net/valtechdb?retryWrites=true&w=majority"
let app = express();
app.use(express.json());

let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;

let Hero = mongoose.model("Hero", Schema({
    id : ObjectId,
    title : String,
    firstname : String,
    lastname : String
}));
mongoose.connect(url)
.then(function(){
    console.log("db connected");
}).catch(function(err){
    console.log("error", err)
});

app.get("/",function(req,res){
    Hero.find().then(dbres=>{
        res.json(dbres);
        res.end();
    })
})

app.listen(7101,"localhost",function(error){
    if(error){
        console.log("Error", error)
    }else{
        console.log("Server is live on localhost:7101");
    }

})