// let message:string = "Welcome to your life";
// alert(message);

//let user:string = "hi";
// let user:string[] = ["hi"];
// let user:Array<string> = ["hi"];
// let user:(number|Array<string|number>) = ["hi",5];

let user:any =5;
let val : boolean=true;

function adder1(num1:number,num2:number, num3?:number):number{
    return num1+num2;
}
function adder(num1:number,num2:number, num3?:number):string{
    return "hi"+num1+num2;
}
interface IPerson{
    name:string;
    canwalk():string;
}
interface IHero{
    title:string;
    firstname:string;
    lastname:string;
    fullname():string;
}

class Person implements IPerson{
    constructor(public name:string){}
    
    canwalk(){
        return "Hi";
    }
}

class Hero extends Person implements IHero{
    #mission="secret";//private
    static version =10101

    constructor(
        public title:string,
        public firstname:string,
        public lastname:string 
        ){
        super(title);
    }
    fullname(){
        return this.firstname+" "+this.lastname;
    }
}