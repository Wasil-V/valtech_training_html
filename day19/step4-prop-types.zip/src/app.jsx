import { Component } from "react";
import ChildComp from "./child.component";


class App extends Component{
    render(){
        return <div>
                <ChildComp title="Child Component" power={5} version={1} ></ChildComp>
        </div>
    }
}

export default App;