import { Component } from "react";
import PropTypes from "prop-types";

class ChildComp extends Component{

    render(){
        return <div>
                <h2>Title : {this.props.title}</h2>
                <h2>Power : {this.props.power}</h2>
                <h2>Version :{this.props.version}</h2>
        </div>
    }

} 
ChildComp.propTypes ={
    title : PropTypes.string.isRequired,
    power : PropTypes.number.isRequired
}

export default ChildComp;