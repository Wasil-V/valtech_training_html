import { Component } from "react";
import ChildComp from "./child-comp";

class App extends Component{
    state ={
        power : 0,
        title : "Component Communication"
    }
    increasePower = ()=>{
        this.setState({
            power : this.state.power +1
        })
    }
    decreasePower = ()=>{
        this.setState({
            power : this.state.power-1
        })
    }
    changeTitle = (ntitle)=>{
        this.setState({
            title : ntitle
        })
    }
    render(){
        return <div>
            <h2>Title : {this.state.title}</h2>
            <h2>Power : {this.state.power}</h2>
            <hr />
            <button onClick={()=>this.increasePower()}>Increase Power</button>
            <button onClick={(()=>this.decreasePower())}>Decrease Power</button>
            <ChildComp power={this.state.power} title={this.changeTitle}/>

        </div>
    }
}
 export default App