// import { Component } from "react";

// class Apper extends Component{

//     state={
//         showTerms :false
//     }
//     toggleConditions = ()=>{
//         this.setState({
//             showTerms : !this.state.showTerms
//         })
//     }

//     render(){
//         return <div>
//             <label htmlFor="">Terms and Conditions</label>
//             <input onChange={this.toggleConditions} type="checkbox"></input>
//            {this.state.showTerms && <fieldset>
//             <legend>Terms and Conditions</legend>
//             <p>
//                 Lorem ipsum dolor sit, amet consectetur adipisicing elit. Mollitia commodi nostrum similique esse repellendus, ipsum minus, ducimus quis, aspernatur id veniam ratione doloremque dolores enim exercitationem aut suscipit soluta fugit.
//                 Lorem ipsum dolor sit amet consectetur adipisicing elit. Sint architecto ipsum pariatur molestiae aliquam? A adipisci, vitae nemo veniam ut deleniti quibusdam minima, repellat explicabo nesciunt, eaque magnam laborum saepe!
//                 Lorem ipsum dolor sit amet consectetur adipisicing elit. Libero culpa deserunt saepe, aperiam nostrum odio cumque optio quibusdam dicta quasi officiis pariatur repellendus omnis, iusto adipisci soluta nisi. Vel, ad.
//             </p>
//            </fieldset> 
//                }
//         </div>
        

//     }

// }

// export default Apper