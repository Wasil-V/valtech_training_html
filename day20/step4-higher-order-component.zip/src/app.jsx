import { Component } from "react";
import PowerClick from "./components/powerclick";
import PowerSlide from "./components/powerslide";

class App extends Component{
    render(){
        return <div>
            <h2>Appliation Component</h2>
            <PowerClick city="Bangalore" title="PowerClick"/>
            <PowerSlide city="Mangalore" title="PowerSlide"/>
        </div>
    }
}

export default App