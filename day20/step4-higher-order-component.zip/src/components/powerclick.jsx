import { Component } from "react";
import WithPower from "../withpower";

class PowerClick extends Component{
    render(){
        return <div style={{border : "2px solid black", margin : "5px", padding : "5px"}}>
                <h2>PowerClick Component</h2>
                <h3>Power : {this.props.power}</h3>
                <h3>Version : {this.props.version}</h3>
                <h3>Title : {this.props.title}</h3>
                <h3>City : {this.props.city}</h3>
                <button onClick={this.props.increasePower}>Increase Power</button>
                <button onClick={this.props.increaseVersion}>Increase Version</button>
        </div>
    }
}

export default WithPower(PowerClick)