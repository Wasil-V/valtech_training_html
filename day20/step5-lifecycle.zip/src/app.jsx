import { Component } from "react";
import ChildComp from "./child.component";


class App extends Component{
    render(){
        return <div>
            <h2>Application Component</h2>
            <button>Increase</button>
            <ChildComp/>

        </div>
    }
}

export default App