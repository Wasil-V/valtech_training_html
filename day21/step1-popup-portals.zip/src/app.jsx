import { Component } from "react";
import PopUp from "./components/popup.component";

class app extends Component{
    state={
        title: "Hello",
        showpopup: false
    }
    togglePopUp = () => {
        this.setState({
            showpopup : !this.state.showpopup
        })
    }
    changeTitle = () => {
        this.setState({
            title: "title is changed"
        })
    }
    render(){
        return<div>
            <h1>App Component</h1>
            {this.state.showpopup ?
            <PopUp>
                <div>
                <h1>{this.state.title}</h1>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Est, provident repellendus. Obcaecati repellat numquam natus porro, et nihil nemo ipsam voluptatem odio ad, perspiciatis dolore delectus deserunt magnam voluptas aliquam?</p>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Est, provident repellendus. Obcaecati repellat numquam natus porro, et nihil nemo ipsam voluptatem odio ad, perspiciatis dolore delectus deserunt magnam voluptas aliquam?</p>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Est, provident repellendus. Obcaecati repellat numquam natus porro, et nihil nemo ipsam voluptatem odio ad, perspiciatis dolore delectus deserunt magnam voluptas aliquam?</p>
                <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Est, provident repellendus. Obcaecati repellat numquam natus porro, et nihil nemo ipsam voluptatem odio ad, perspiciatis dolore delectus deserunt magnam voluptas aliquam?</p>

                <button onClick={this.togglePopUp}>Hide popup</button>
                <button onClick={this.changeTitle}>Change Title</button>
            
        </div>
        </PopUp> : <button onClick={this.togglePopUp}>show popup window</button>}
        </div>
    }
}
export default app;