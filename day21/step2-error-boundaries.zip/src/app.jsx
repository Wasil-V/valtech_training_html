import { Component } from "react";
import ErrprBoundary from "./component/error.component";
import HeroComp from "./component/hero";
 
class App extends Component{
    state = {
        title : "Welcome to your life",
    }
    render(){
        return <div>
                <h1>{ this.state.title }</h1>
                <ErrprBoundary>  <HeroComp power={Math.round( Math.random() * 10)}/> </ErrprBoundary>
                <ErrprBoundary>  <HeroComp power={Math.round( Math.random() * 10)}/> </ErrprBoundary>
                <ErrprBoundary>  <HeroComp power={Math.round( Math.random() * 10)}/> </ErrprBoundary>
                <ErrprBoundary>  <HeroComp power={Math.round( Math.random() * 10)}/> </ErrprBoundary>
                <ErrprBoundary>  <HeroComp power={Math.round( Math.random() * 10)}/> </ErrprBoundary>
               </div>
    }
}
 
export default App;