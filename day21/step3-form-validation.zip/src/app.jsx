import { Component } from "react";
 
class App extends Component{
    state = {
        apptitle : "Forms in React",
        htitle : "",
        hname : "",
        hpower : 0,
        htitle_error : "",
        hname_error : "",
        hpower_error : "",
    }
    /* 
    titleChangeHandler = (evt)=>{
        this.setState({
            htitle : evt.target.value
        })
    }
    nameChangeHandler = (evt)=>{
        this.setState({
            hname : evt.target.value
        })
    }
    powerChangeHandler = (evt)=>{
        this.setState({
            hpower : evt.target.value
        })
    } 
    */
    changeHandler = (evt)=>{
        this.setState({
            [evt.target.id] : evt.target.value
        })
    }
    validateForm = ()=> {
        if( this.state.htitle == ""){
            this.setState({
                htitle_error : "Title is required"
            })
        }
        if(this.state.hname == ""){
            this.setState({
                hname_error : "Name is required"
            })
        }
        if(this.state.hpower == 0){
            this.setState({
                hpower_error : "Power is required"
            })
        }else if(this.state.hpower < 5 && this.state.hpower > 0){
            this.setState({
                hpower_error : "Power is less"
            })
        }else{
            this.setState({
                hpower_error : "Power is more"
            })
        }
    }
    render(){
        return <div className="container">
                <h1>{ this.state.apptitle }</h1>
                    <div className="mb-3">
                        <label htmlFor="htitle" className="form-label">Title</label>
                        <input onInput={ (evt) => this.changeHandler(evt) } value={this.state.htitle} id="htitle" type="text" className="form-control"/>
                        { this.state.htitle_error !== "" && <div className="form-text text-danger">{ this.state.htitle_error }</div> }
                    </div>
                    <div className="mb-3">
                        <label htmlFor="hname" className="form-label">Name</label>
                        <input onInput={ (evt) => this.changeHandler(evt) } value={this.state.hname} id="hname" type="text" className="form-control"/>
                        { this.state.hname_error !== "" && <div className="form-text text-danger">Name is required</div> }
                    </div>
                    <div className="mb-3">
                        <label htmlFor="hpower" className="form-label">Power</label>
                        <input onInput={ (evt) => this.changeHandler(evt) } value={this.state.hpower} id="hpower" type="range" className="form-control"/>
                        { (this.state.hpower <5 && this.state.hpower >0) && <div className="form-text text-danger">Power is less</div> }
                        { this.state.hpower > 10 && <div className="form-text text-danger">Power is more</div> }
                        { this.state.hpower_error == "Power is required" && <div className="form-text text-danger">Power is required</div> }
                    </div>
                    <button type="submit" onClick={ this.validateForm } className="btn btn-primary">Submit</button>
                    <ul>
                        <li>Title : { this.state.htitle }</li>
                        <li>Name : { this.state.hname }</li>
                        <li>Power : { this.state.hpower }</li>
                    </ul>
               </div>
    }
}
 
export default App;
 
 
