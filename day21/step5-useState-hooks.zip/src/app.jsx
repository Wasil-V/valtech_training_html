import { Component } from "react";
import UseComp from "./component/useState.component";
import UseStateObjComp from "./component/useStateObjext.component";
 
class App extends Component{
    state = {
        apptitle : "Hooks",
        
    }
    render(){
        return <div className="container">
                <h1>{ this.state.apptitle }</h1>
                <hr />
                <UseComp/>
                <hr />
                <UseStateObjComp/>
               </div>
    }
}
 
export default App;
 
 
