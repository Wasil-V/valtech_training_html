import { useState } from "react"

let UseComp =()=>{
    let[power,setPower]=useState(0);
    let increasePower = function(){
        setPower(power+1);
    }
    return <div>
        <h1>User State Hook Component</h1>
        <h2>Power : {power}</h2>
        <button onClick={increasePower}>Increase Power</button>
    </div>
}

export default UseComp