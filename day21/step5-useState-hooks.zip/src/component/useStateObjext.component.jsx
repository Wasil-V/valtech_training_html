import { useState } from "react"

let UseStateObjComp =()=>{
    let[hero,setHero]=useState({firstname : "", lastname : ""});

    let addHeroName = function(evt){
        setHero({
            ...hero,
            [evt.target.title] : evt.target.value
        })
    }
    return <div>
        <h1>User State Hook Component</h1>
        <h2>First Name : {hero.firstname}</h2>
        <h2>Last Name : {hero.lastname}</h2>
        <label htmlFor="fname">First Name: <input onChange={(evt)=>addHeroName(evt)} id="fname" title="firstname" type="text" /></label>
        <br />
        <br />
        <label htmlFor="lname">Last Name: <input onChange={(evt)=>addHeroName(evt)} id="lname" title="lastname" type="text" /></label>
    </div>
}

export default UseStateObjComp