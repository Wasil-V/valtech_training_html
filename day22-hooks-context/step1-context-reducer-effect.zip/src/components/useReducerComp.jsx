import { useRef } from "react"
import { useReducer } from "react"

let UseReducerComp = ()=>{

    let fname =useRef();
    let lname =useRef();
    let cname =useRef();
    let reducerFun= (state,action)=>{
        switch(action.type){
            case "UPDATE_FIRSTNAME": return {...state, firstname : action.payload}
            case "UPDATE_LASTNAME": return {...state, lastname : action.payload}
            case "UPDATE_CITY": return {...state, city : action.payload}
            default : return state
        }
    }

    let [state,dispatch] = useReducer(reducerFun,{firstname : "", lastname : "", city : ""})

    return <div>
                <h2>UseReducer Hook</h2>
                <h3>First Name : { state.firstname }</h3>
                <input type="text" ref={fname} />
                <button onClick={()=>dispatch({type:"UPDATE_FIRSTNAME", payload : fname.current.value})}>Set First Name</button>
                <h3>Last Name : { state.lastname }</h3>
                <input type="text" ref={lname} />
                <button onClick={()=>dispatch({type:"UPDATE_LASTNAME", payload : lname.current.value})}>Set Last Name</button>
                <h3>City : { state.city}</h3>
                <input type="text" ref={cname} />
                <button onClick={()=>dispatch({type:"UPDATE_CITY", payload : cname.current.value})}>Set City</button>
            </div>

}

export default UseReducerComp