const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const { json } = require("express");
let errorHandler = require("./utils").errorHandler;
const config = require("./config.json")

let app = express();

let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let port = process.env.PORT || config.port;

let Hero = mongoose.model("Hero", Schema({
    id : ObjectId,
    title : String,
    firstname : String,
    lastname : String
}))

mongoose.connect(`mongodb+srv://${config.dbuser}:${config.password}@cluster0.x4x3eny.mongodb.net/${config.dbname}?retryWrites=true&w=majority`
).then(function(){
    console.log("Db Connected")
}).catch ((error)=>{
    console.log("Error ",error);
});


app.use(express.static(__dirname+"/public"));
app.use(express.json())
.use(cors());
// app.get("/",(req,res)=>{
//     res.send("Hello Express");
// })

//READ
app.get("/data",function(req,res){
    Hero.find().then(dbres=>res.json(dbres))
        
    });

//CREATE

app.post("/data",(req,res)=>{
    let hero = new Hero(req.body);
    hero.save()
    .then(dbreq=>{
        res.send({message : "hero added"})
        console.log("db updated")
    })
    .catch(err=>errorHandler)
})

//UPdate

app.post("/update/:hid", (req, res)=>{
    console.log("update request received")
   Hero.findByIdAndUpdate({_id : req.params.hid})
  .then(dbRes=>{
    console.log(dbRes);
        dbRes.title = req.body.title;
        dbRes.firstname = req.body.firstname;
        dbRes.lastname = req.body.lastname;
        dbRes.save().then(updateRes=>res.send({ message : "hero info updated"} ))
  })
  .catch(error=>errorHandler);
})
//READ UPDATE
app.get("/edit/:heroid", (req, res)=>{
    Hero.findById({ _id : req.params.heroid }).then(dbres => {
        res.send(dbres)
    })
})

//DELETE
app.delete("/delete/:hid",(req, res)=>{

    Hero.findByIdAndDelete({ _id : req.params.hid })
    .then(dbRes => res.send({ message : "hero deleted", hero : dbRes.title}))
});

app.listen(port,config.host,errorHandler);
console.log(`Server is now live on : ${port}`);
