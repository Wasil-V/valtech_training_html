import Users from "./user.component"

let App =()=>{
    return <div>
        <h1>Ajax Hooks</h1>
        <hr />
        <Users/>
    </div>
}
export default App