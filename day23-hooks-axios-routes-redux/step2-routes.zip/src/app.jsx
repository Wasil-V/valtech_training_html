import {BrowserRouter,  Route, Routes,NavLink} from "react-router-dom"
import AquamanComp from "./components/aquaman.component";
import BatmanComp from "./components/batman.component";
import HomeComp from "./components/home.component";
import NotFound from "./components/notfound.component";
import SupermanComp from "./components/superman.component";
import WonderWomenComp from "./components/wonderwomen.component";
import "./myroutes.css"
function App(){
    let activeFun1 = ({isActive})=> isActive ? 'box' : 'plainBox';
  let activeFun2 = ({isActive})=> {
    return {
      width: "200px",
      display: "inline-block",
      backgroundColor: isActive ? "crimson" : "darkorange",
      color:  "papayawhip",
      textAlign: "center",
      padding: "5px",
    }
  };
    return (
         <div>
            <h1>React Routing 101</h1>
            <BrowserRouter>
            {/* <ul>
                <li><Link to="/">Home Component</Link></li>
                <li><Link to="superman">Superman Component</Link></li>
                <li><Link to="batman">Batman Component</Link></li>
                <li><Link to="aquaman">Aquaman Component</Link></li>
                <li><Link to="wonderwomen">Wonderwoman Component</Link></li>
                <li><Link to="flash">Flash Component</Link></li>
                <li><Link to="cyborg">Cyborg Component</Link></li>
            </ul> */}
            <ul>
                <li><NavLink className={activeFun1} to="/" end>Home Component</NavLink></li>
                <li><NavLink className={({isActive})=>isActive ? "box" : ""} to="superman">Superman Component</NavLink></li>
                <li><NavLink style={activeFun2} to="batman">Batman Component</NavLink></li>
                <li><NavLink className={({isActive})=>isActive ? "box" : ""} to="aquaman">Aquaman Component</NavLink></li>
                <li><NavLink className={({isActive})=>isActive ? "box" : ""} to="wonderwomen">Wonderwoman Component</NavLink></li>
                <li><NavLink className={({isActive})=>isActive ? "box" : ""} to="flash">Flash Component</NavLink></li>
                <li><NavLink className={({isActive})=>isActive ? "box" : ""} to="cyborg">Cyborg Component</NavLink></li>
            </ul>
            <Routes>
                <Route path="/" element={<HomeComp/>}></Route>
                <Route path="superman" element={<SupermanComp/>}></Route>
                <Route path="batman" element={<BatmanComp/>}></Route>
                <Route path="wonderwomen" element={<WonderWomenComp/>}></Route>
                <Route path="aquaman" element={<AquamanComp/>}></Route>
                <Route path="flash" element={<SupermanComp/>}></Route>
                <Route path="*" element={<NotFound/>}></Route>
            </Routes>
            </BrowserRouter>

        </div>
    )
}

export default App;