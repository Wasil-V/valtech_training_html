function AquamanComp(){
    return (
         <div>
            <h2>AquamanComp Component</h2>
        </div>
    )
}

export default AquamanComp;