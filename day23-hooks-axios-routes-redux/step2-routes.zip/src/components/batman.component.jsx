function BatmanComp(){
    return (
         <div>
            <h2>BatmanComp Component</h2>
        </div>
    )
}

export default BatmanComp;