function NotFound(){
    return (
         <div>
            <h2>NotFound Component</h2>
        </div>
    )
}

export default NotFound;