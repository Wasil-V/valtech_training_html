function WonderWomenComp(){
    return (
         <div>
            <h2>Wonder Woman Component</h2>
        </div>
    )
}

export default WonderWomenComp;