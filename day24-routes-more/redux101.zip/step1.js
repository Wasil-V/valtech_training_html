let redux = require("redux")
let createStore = redux.legacy_createStore;
// action type constant name of an event
//action center is function that returns an action objecy
//reducer is a function which has switch cases to call functions base on action types
//initial state is initial value of store object
//store is an object that stores all shared states of your application
//subscribe / unsubscibe to listen to changes of the store
//dispatch is a method that can take action object

//ACTION
const ADDHERO = "ADDHERO";

//ACTION creator

let addhero = function(){
    return {
        type : ADDHERO
    }
}

let InitialState = {
    numberOfHeroes : 0
}

//Reducer

let reducer =(state = InitialState, action )=>{
    switch(action.type){
        case ADDHERO : return {
            numberOfHeroes :state.numberOfHeroes + 1
        }
        default : return state
    }
}

let store = createStore(reducer);

console.log("initial value of store ", store.getState());

let unsubscribe =store.subscribe(()=>console.log("Subscribed ", store.getState()));

store.dispatch(addhero());
store.dispatch(addhero());
store.dispatch(addhero());
store.dispatch(addhero());
store.dispatch(addhero());
console.log(store.getState());

