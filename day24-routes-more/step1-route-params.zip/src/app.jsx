import React, { Suspense, useState } from "react";
import {BrowserRouter,  Route, Routes,NavLink} from "react-router-dom"
// import BatMovie1Comp from "./components/batmovie1.component";
// import BatMovie2Comp from "./components/batmovie2.component";
// import AquamanComp from "./components/aquaman.component";
// import BatmanComp from "./components/batman.component";
import HomeComp from "./components/home.component";
// import NotFound from "./components/notfound.component";
// import SupermanComp from "./components/superman.component";
// import WonderWomenComp from "./components/wonderwomen.component";
import "./myroutes.css"
let AquamanComp = React.lazy(()=> import("./components/aquaman.component"))
let BatmanComp = React.lazy(()=> import("./components/batman.component"))
let BatMovie1Comp = React.lazy(()=> import("./components/batmovie1.component"))
let BatMovie2Comp = React.lazy(()=> import("./components/batmovie2.component"))
let NotFound = React.lazy(()=> import("./components/notfound.component"))
let SupermanComp = React.lazy(()=> import("./components/superman.component"))
let WonderWomenComp = React.lazy(()=> import("./components/wonderwomen.component"))
function App(){
    let activeFun1 = ({isActive})=> isActive ? 'box' : 'plainBox';
  let activeFun2 = ({isActive})=> {
    return {
      width: "200px",
      display: "inline-block",
      backgroundColor: isActive ? "crimson" : "darkorange",
      color:  "papayawhip",
      textAlign: "center",
      padding: "5px",
    }
  };
  let [qty,setQty]= useState(0);
    return (
         <div>
            <h1>React Routing 101</h1>
            <label htmlFor="qty">Parameter
            <input id="qty" type="range" value={qty} onChange={(evt)=>setQty(evt.target.value)} />
            <b>{qty}</b>
            </label>
            <BrowserRouter>
            {/* <ul>
                <li><Link to="/">Home Component</Link></li>
                <li><Link to="superman">Superman Component</Link></li>
                <li><Link to="batman">Batman Component</Link></li>
                <li><Link to="aquaman">Aquaman Component</Link></li>
                <li><Link to="wonderwomen">Wonderwoman Component</Link></li>
                <li><Link to="flash">Flash Component</Link></li>
                <li><Link to="cyborg">Cyborg Component</Link></li>
            </ul> */}
            <ul>
                <li><NavLink className={activeFun1} to="/" end>Home Component</NavLink></li>
                <li><NavLink className={({isActive})=>isActive ? "box" : ""} to="superman">Superman Component</NavLink></li>
                <li><NavLink style={activeFun2} to="batman">Batman Component</NavLink></li>
                <li><NavLink style={activeFun2} to="/batman/batmovie1">BatMovie1 Component</NavLink></li>
                <li><NavLink style={activeFun2} to="/batman/batmovie2">BatMovie2 Component</NavLink></li>
                <li><NavLink className={({isActive})=>isActive ? "box" : ""} to="aquaman">Aquaman Component</NavLink></li>
                <li><NavLink className={({isActive})=>isActive ? "box" : ""} to={"aquaman/"+qty}>Aquaman Component with Params</NavLink></li>
                <li><NavLink className={({isActive})=>isActive ? "box" : ""} to="wonderwomen">Wonderwoman Component</NavLink></li>
                <li><NavLink className={({isActive})=>isActive ? "box" : ""} to="flash">Flash Component</NavLink></li>
                <li><NavLink className={({isActive})=>isActive ? "box" : ""} to="cyborg">Cyborg Component</NavLink></li>
            </ul>
            <Routes>
                <Route path="/" element={<HomeComp/>}></Route>
                <Route path="superman" element={<Suspense fallback={<>loading..</>}><SupermanComp/></Suspense>}></Route>
                <Route path="batman" element={<Suspense fallback={<>loading..</>}><BatmanComp/></Suspense>}>
                  <Route path="/batman/batmovie1" element={<Suspense fallback={<>loading..</>}><BatMovie1Comp/></Suspense>}></Route>
                  <Route path="/batman/batmovie2" element={<Suspense fallback={<>loading..</>}><BatMovie2Comp/></Suspense>}></Route>
                </Route>
                <Route path="wonderwomen" element={<Suspense fallback={<>loading..</>}><WonderWomenComp/></Suspense>}></Route>
                <Route path="aquaman" element={<Suspense fallback={<>loading..</>}><AquamanComp/></Suspense>}></Route>
                <Route path="aquaman/:qty" element={<Suspense fallback={<>loading..</>}><AquamanComp/></Suspense>}></Route>
                <Route path="flash" element={<Suspense fallback={<>loading..</>}><SupermanComp/></Suspense>}></Route>
                <Route path="*" element={<Suspense fallback={<>loading..</>}><NotFound/></Suspense>}></Route>
            </Routes>
            </BrowserRouter>

        </div>
    )
}

export default App;