import {useParams} from "react-router-dom"
function AquamanComp(){
    let params = useParams()
    return (
         <div>
            <h2>AquamanComp Component</h2>
            <h2>Quantity : {Number(params.qty) + 10 || 0}</h2>
        </div>
    )
}

export default AquamanComp;