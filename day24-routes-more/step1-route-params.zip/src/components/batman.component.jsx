import { Outlet } from "react-router-dom";

function BatmanComp(){
    return (
         <div>
            <h2>BatmanComp Component</h2>
            <Outlet/>
        </div>
    )
}

export default BatmanComp;