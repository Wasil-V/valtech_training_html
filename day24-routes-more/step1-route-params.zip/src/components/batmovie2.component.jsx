function BatMovie2Comp(){
    return (
         <div>
            <h2>BatMovie2Comp</h2>
        </div>
    )
}

export default BatMovie2Comp;