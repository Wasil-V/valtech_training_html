function HomeComp(){
    return (
         <div>
            <h2>HomeComp Component</h2>
        </div>
    )
}

export default HomeComp;