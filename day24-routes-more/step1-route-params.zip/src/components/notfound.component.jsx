function NotFound(){
    return (
         <div>
            <h2>Not Found Component</h2>
        </div>
    )
}

export default NotFound;