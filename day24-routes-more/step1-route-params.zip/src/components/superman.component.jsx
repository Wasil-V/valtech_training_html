import {useNavigate} from "react-router-dom"
function SupermanComp(){
    let  batNav = useNavigate();
    let  aquaNav = useNavigate();
    return (
        <div>
        <h1>Superman Component</h1>
         {/* 
         replace true will replace the history stack
         replace false will keep the histroy stack 
         */}
        <button onClick={ ()=> batNav("/batman", { replace : true })}>Navigate to Batman</button>
        <button onClick={ ()=> aquaNav("/aquaman/", { replace : true })}>Navigate to Batman</button>
      </div>
    )
}

export default SupermanComp;