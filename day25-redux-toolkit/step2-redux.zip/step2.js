const redux = require("redux")

const createStore = redux.legacy_createStore

const ADDHERO = "ADDHERO";
const REMOVEHERO = "REMOVEHERO"
const SETHERO = "SETHERO"

let addhero =function(){
    return{
        type : ADDHERO
    }
}
let removehero =function(){
    return{
        type : REMOVEHERO
    }
}
let sethero =function(num){
    return{
        type : SETHERO,
        payload : num
    }
}

let InitialState ={
    numberofHeroes : 0
}

let reducer =(state = InitialState,action)=>{
    switch(action.type){
        case ADDHERO : return {numberofHeroes : state.numberofHeroes + 1} 
        case REMOVEHERO : return {numberofHeroes : state.numberofHeroes - 1} 
        case SETHERO : return {numberofHeroes : action.payload } 
        default : return state
    }
}

let store = createStore(reducer)

console.log("innitial state ", store.getState())

let unsubscribe = store.subscribe(()=>console.log("Subscribed ",store.getState()))

store.dispatch(addhero());
store.dispatch(addhero());
store.dispatch(addhero());
store.dispatch(removehero());
store.dispatch(sethero(5));







