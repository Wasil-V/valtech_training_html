const redux = require("redux")

const createStore = redux.legacy_createStore

const ADDHERO = "ADDHERO";
const REMOVEHERO = "REMOVEHERO"
const SETHERO = "SETHERO"
const ADDMOVIE = "ADDMOVIE";
const REMOVEMOVIE = "REMOVEMOVIE"
const SETMOVIE = "SETMOVIE"

let addhero =function(){
    return{
        type : ADDHERO
    }
}
let removehero =function(){
    return{
        type : REMOVEHERO
    }
}
let sethero =function(num){
    return{
        type : SETHERO,
        payload : num
    }
}
let addmovie =function(){
    return{
        type : ADDMOVIE
    }
}
let removemovie =function(){
    return{
        type : REMOVEMOVIE
    }
}
let setmovie =function(num){
    return{
        type : SETMOVIE,
        payload : num
    }
}

let InitialState ={
    numberofHeroes : 0,
    numberofMovies : 0
}

let reducer =(state = InitialState,action)=>{
    switch(action.type){
        case ADDHERO : return {...state, numberofHeroes : state.numberofHeroes + 1} 
        case REMOVEHERO : return {...state, numberofHeroes : state.numberofHeroes - 1} 
        case SETHERO : return {...state, numberofHeroes : action.payload } 
        case ADDMOVIE : return {...state, numberofMovies : state.numberofMovies + 1} 
        case REMOVEMOVIE : return {...state, numberofMovies : state.numberofMovies - 1} 
        case SETMOVIE : return {...state, numberofMovies : action.payload } 
        default : return state
    }
}

let store = createStore(reducer)

console.log("innitial state ", store.getState())

let unsubscribe = store.subscribe(()=>console.log("Subscribed ",store.getState()))

store.dispatch(addhero());
store.dispatch(addhero());
store.dispatch(addhero());
store.dispatch(removehero());
store.dispatch(sethero(5));
store.dispatch(addmovie());
store.dispatch(addmovie());
store.dispatch(addmovie());
store.dispatch(removemovie());
store.dispatch(setmovie(5));







