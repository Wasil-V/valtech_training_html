const redux = require("redux")
const logger =require("redux-logger").createLogger

const createStore = redux.legacy_createStore
const combineReducers = redux.combineReducers
const bindActionCreators = redux.bindActionCreators;
const applyMiddleware = redux.applyMiddleware;

const ADDHERO = "ADDHERO";
const REMOVEHERO = "REMOVEHERO"
const SETHERO = "SETHERO"
const ADDMOVIE = "ADDMOVIE";
const REMOVEMOVIE = "REMOVEMOVIE"
const SETMOVIE = "SETMOVIE"

let addhero =function(){
    return{
        type : ADDHERO
    }
}
let removehero =function(){
    return{
        type : REMOVEHERO
    }
}
let sethero =function(num){
    return{
        type : SETHERO,
        payload : num
    }
}
let addmovie =function(){
    return{
        type : ADDMOVIE
    }
}
let removemovie =function(){
    return{
        type : REMOVEMOVIE
    }
}
let setmovie =function(num){
    return{
        type : SETMOVIE,
        payload : num
    }
}

let InitialHeroState ={
    numberofHeroes : 0
    
}
let InitialMovieState ={
    numberofMovies : 0
    
}

let heroReducer =(state = InitialHeroState,action)=>{
    switch(action.type){
        case ADDHERO : return {...state, numberofHeroes : state.numberofHeroes + 1} 
        case REMOVEHERO : return {...state, numberofHeroes : state.numberofHeroes - 1} 
        case SETHERO : return {...state, numberofHeroes : action.payload } 
        default : return state
    }
}
let movieReducer =(state = InitialMovieState,action)=>{
    switch(action.type){
        case ADDMOVIE : return {...state, numberofMovies : state.numberofMovies + 1} 
        case REMOVEMOVIE : return {...state, numberofMovies : state.numberofMovies - 1} 
        case SETMOVIE : return {...state, numberofMovies : action.payload } 
        default : return state
    }
}

let rootReducer = combineReducers({
    heroes : heroReducer,
    movies : movieReducer
})

let store = createStore(rootReducer,applyMiddleware(logger()))

console.log("innitial state ", store.getState())

let unsubscribe = store.subscribe(function(){})

let action = bindActionCreators({addhero, removehero, sethero, addmovie, removemovie, setmovie},store.dispatch)

action.addhero();
action.addhero();
action.addhero();
action.removehero();
action.sethero(8);
action.addmovie();
action.addmovie();
action.addmovie();
action.removemovie();
action.setmovie(8);









